# Betting Boyz — SofaScore Prediction Bot (No Odds)

This bot sends **confidence-based football predictions** using **SofaScore** data only.

✅ No bookmaker odds  
✅ No paid quota  
✅ Pure prediction mode  

## GitHub Secrets (exact names)

Add these in: **Settings → Secrets and variables → Actions → New repository secret**

- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_WHATSAPP_FROM` (example: `whatsapp:+14155238886`)
- `TO_WHATSAPP_NUMBER` (example: `whatsapp:+27733647400`)
- `WHATSAPP_CHANNEL_LINK` (optional)
